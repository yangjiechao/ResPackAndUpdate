﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleUpdate : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        VersionManager.inst.OnVersionError = (phase, err) => {
            //Debug.LogError(phase + ":" + err);
            Debug.LogError("错误," + phase + ":" + err);
        };
        VersionManager.inst.OnVersionPhaseChange = (phase) => {
            Debug.LogError(phase);
            if (phase == VersionManager.Phase.Complected)
            {
                Debug.LogError("下载完成");

            }
            else if (phase == VersionManager.Phase.Check)
            {
                Debug.LogError("对比资源中...");
            }
            else if (phase == VersionManager.Phase.Copy)
            {
                Debug.LogError("复制目录...");
            }
            else if (phase == VersionManager.Phase.UnZip)
            {
                Debug.LogError("资源解压中...");
            }
            else if (phase == VersionManager.Phase.DownLoad)
            {
                Debug.LogError(string.Format("下载资源中当前下载版本：{0}/目标版本:{1}", VersionManager.inst.curVersion, VersionManager.inst.serVersion));
            }
        };
    }

    private void Update()
    {
        Debug.LogError( VersionManager.inst.GetDownLoadProgress());
    }

    // Update is called once per frame
    void OnGUI()
    {
        if (GUILayout.Button("更新"))
        {
#if UNITY_ANDROID
            VersionManager.inst.Init("http://192.168.6.215/res/Android");
#elif UNITY_IOS
            VersionManager.inst.Init("http://192.168.6.215/res/iOS");
#endif
        }
    }
}
