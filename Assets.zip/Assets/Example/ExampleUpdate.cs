﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleUpdate : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.LogError(Application.persistentDataPath);
        VersionManager.inst.OnVersionError = (phase, err) => {
            //Debug.LogError(phase + ":" + err);
            Debug.LogError("错误," + phase + ":" + err);
        };
        VersionManager.inst.OnVersionPhaseChange = (phase) => {
            Debug.LogError(phase);
            if (phase == VersionManager.Phase.Complected)
            {
                Debug.LogError("下载完成");
                tex = loadAb<Texture>("pic/download");
            }
            else if (phase == VersionManager.Phase.Check)
            {
                Debug.LogError("对比资源中...");
            }
            else if (phase == VersionManager.Phase.Copy)
            {
                Debug.LogError("复制目录...");
            }
            else if (phase == VersionManager.Phase.UnZip)
            {
                Debug.LogError("资源解压中...");
            }
            else if (phase == VersionManager.Phase.DownLoad)
            {
                Debug.LogError(string.Format("下载资源中当前下载版本：{0}/目标版本:{1}", VersionManager.inst.curVersion, VersionManager.inst.serVersion));
            }
        };
    }
    IEnumerator loadTex()
    {
        yield return null;
    }
    private void Update()
    {

    }
    Texture tex;
    // Update is called once per frame
    void OnGUI()
    {
        if (GUILayout.Button("更新"))
        {
#if UNITY_ANDROID
            VersionManager.inst.Init("http://192.168.6.215/res/Android");
#elif UNITY_IOS
            VersionManager.inst.Init("http://192.168.6.215/res/iOS");
#endif
        }
        if (tex != null)
        {
            GUILayout.Label(tex);
        }
    }
    string _parsisResPath = null;
    /// <summary>
    /// 持久化目录资源路径
    /// </summary>
    string parsisResPath
    {
        get
        {
            if (_parsisResPath == null)
            {
                _parsisResPath = Application.persistentDataPath + "/Resources/";
            }
            return _parsisResPath;
        }
    }
    string abSuffix = ".unity3d";
    private T loadAb<T>(string path) where T : UnityEngine.Object
    {
        if (!path.EndsWith(abSuffix))
        {
            path = path.ToLower() + abSuffix;
        }
        string _path = parsisResPath + path;
        if (!System.IO.File.Exists(_path))
        {
            return default(T);
        }
        AssetBundle ab = AssetBundle.LoadFromFile(_path);
        if (ab != null)
        {
            Object obj = ab.LoadAsset(System.IO.Path.GetFileNameWithoutExtension(path));
            ab.Unload(false);
            if (obj != null)
            {
                return obj as T;
            }
        }
        return default(T);
    }
}
