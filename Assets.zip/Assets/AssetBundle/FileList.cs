﻿//-------------------------------------------------
// Copyright © 2019  yangjiechao
//-------------------------------------------------
using System.Collections.Generic;
[System.Serializable]
public class FileList
{
    public List<FileItemInfo> list;
}
[System.Serializable]
public class FileItemInfo
{
    public string path;
    public string md5;
}
