﻿//-------------------------------------------------
// Copyright © 2019  yangjiechao
//-------------------------------------------------
#if UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Compression;
public class EditorZipTool 
{
    const string suffix = ".zip";
    /// <summary>
    /// 压缩
    /// </summary>
    /// <param name="srcPath"></param>
    /// <param name="destPath"></param>
    /// <param name="zipName"></param>
    public static void Zip(string srcPath, string destPath, string zipName)
    {
        if (string.IsNullOrEmpty(srcPath) || string.IsNullOrEmpty(destPath) || string.IsNullOrEmpty(zipName))
        {
            Debug.LogError(string.Format("解压出错,srcPath={0},destPath={1},zipName={2}", srcPath, destPath, zipName));
            return;
        }
        if (!System.IO.Directory.Exists(srcPath))
        {
            Debug.LogError("找不到压缩目录" + srcPath);
            return;
        }
        if (!System.IO.Directory.Exists(destPath))
        {
            System.IO.Directory.CreateDirectory(destPath);
        }
        if (!zipName.EndsWith(suffix))
        {
            zipName += suffix;
        }
        ZipFile.CreateFromDirectory(srcPath, destPath + "/" + zipName);
    }
}
#endif