﻿//-------------------------------------------------
// Copyright © 2019  yangjiechao
//-------------------------------------------------
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using System;
using System.Security.Cryptography;
using System.Text;
public class ResPackage : EditorWindow
{
    [MenuItem("Nat/资源打包")]
    static void Open()
    {
        ResPackage win = EditorWindow.GetWindow<ResPackage>("资源打包");
        win.Show();
    }
    string _savePath;
    string savePath
    {
        get
        {
            _savePath = PlayerPrefs.GetString(Application.productName + "_PackagePath");
            return _savePath;
        }
        set
        {
            _savePath = value;
            PlayerPrefs.SetString(Application.productName + "_PackagePath", _savePath);
        }
    }
    string _resPath;
    string buildPath
    {
        get
        {
            _resPath = PlayerPrefs.GetString(Application.productName + "_NeedPackagePath");
            return _resPath;
        }
        set
        {
            _resPath = value;
            PlayerPrefs.SetString(Application.productName + "_NeedPackagePath", _resPath);
        }
    }
    //string _fLPath;
    string flPath
    {
        get
        {
            return savePath + (platform == PlatformType.Android?"/Android":"/iOS");
        }
    }
    //{
    //    get
    //    {
    //        _fLPath = PlayerPrefs.GetString(Application.productName + "_FileListPath");
    //        return _fLPath;
    //    }
    //    set
    //    {
    //        _fLPath = value;
    //        PlayerPrefs.SetString(Application.productName + "_FileListPath", _fLPath);
    //    }
    //}
    string fileListPath
    {
        get
        {
            return string.Format("{0}/fileList_{1}.txt",flPath, version - 1);
        }
    }
    string newFileListPath
    {
        get
        {
            return string.Format("{0}/fileList_{1}.txt", flPath, version);
        }
    }
    int _version;
    int version
    {
        get
        {
            _version = PlayerPrefs.GetInt(Application.productName + "_PackageVersion", 0);
            return _version;
        }
        set
        {
            _version = value;
            PlayerPrefs.SetInt(Application.productName + "_PackageVersion", _version);
        }
    }
    string _abSuffix;
    string abSuffix
    {
        get
        {
            _abSuffix = PlayerPrefs.GetString(Application.productName + "_ABSuffix", "unity3d");
            return _abSuffix;
        }
        set
        {
            _abSuffix = value;
            PlayerPrefs.SetString(Application.productName + "_ABSuffix", _abSuffix);
        }
    }
    string _localVerPath;
    string localVerPath
    {
        get
        {
            _localVerPath = PlayerPrefs.GetString(Application.productName + "_localVerPath");
            return _localVerPath;
        }
        set
        {
            _localVerPath = value;
            PlayerPrefs.SetString(Application.productName + "_localVerPath", _localVerPath);
        }
    }
    bool _updateLocalVersion;
    bool updateLocalVersion
    {
        get
        {
            _updateLocalVersion = PlayerPrefs.GetInt(Application.productName + "_updateLocalVersion",0)==0;
            return _updateLocalVersion;
        }
        set
        {
            _updateLocalVersion = value;
            PlayerPrefs.SetInt(Application.productName + "_updateLocalVersion", _updateLocalVersion?0:1);
        }
    }
    public enum PlatformType
    {
        Android,
        iOS,
    }
    PlatformType platform;
    private void OnGUI()
    {
        //GUILayout.BeginHorizontal();
        //flPath = EditorGUILayout.TextField("文件列表目录", flPath);
        //if (GUILayout.Button("修改", GUILayout.Width(50)))
        //{
        //    flPath = EditorUtility.OpenFolderPanel("选择文件夹", flPath, "fileList");
        //}
        //GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        buildPath = EditorGUILayout.TextField("资源目录", buildPath);
        if (GUILayout.Button("修改", GUILayout.Width(50)))
        {
            buildPath = EditorUtility.OpenFolderPanel("选择文件夹", buildPath, "Resources");
        }
        GUILayout.EndHorizontal();
        abSuffix = EditorGUILayout.TextField("AB后缀", abSuffix);
        GUILayout.BeginHorizontal();
        savePath = EditorGUILayout.TextField("输出目录", savePath);
        if (GUILayout.Button("修改", GUILayout.Width(50)))
        {
            savePath = EditorUtility.OpenFolderPanel("选择文件夹", savePath, "resOut");
        }
        GUILayout.EndHorizontal();
        version = EditorGUILayout.IntField("版本号", version);
        GUILayout.BeginVertical(EditorStyles.textArea);
        GUILayout.Label("用于打包客户端时确认客户端本地版本");
        GUILayout.BeginHorizontal();
        localVerPath = EditorGUILayout.TextField("编辑器版本文件", localVerPath);
        if (GUILayout.Button("修改", GUILayout.Width(50)))
        {
            localVerPath = EditorUtility.OpenFilePanel("选择ver.txt", localVerPath,"txt");
        }
        GUILayout.EndHorizontal();
        updateLocalVersion = EditorGUILayout.Toggle("是否打包完后更新客户端版本", updateLocalVersion);
        GUILayout.EndVertical();
        platform = (PlatformType)EditorGUILayout.EnumPopup("平台", platform);
        if (GUILayout.Button("打包"))
        {
            if(string.IsNullOrEmpty(flPath)||
                string.IsNullOrEmpty(buildPath) ||
                string.IsNullOrEmpty(savePath)||
                string.IsNullOrEmpty(localVerPath))
            {
                EditorUtility.DisplayDialog("错误", "有路径为空，请确定填写再试", "好的");
                return;
            }
            //先获取文件列表
            loadFileList();
            if (cancelPack)
            {
                cancelPack = false;
                return;
            }
            if (needBuildFiles.Count == 0)
            {
                EditorUtility.DisplayDialog("警告", "没有改动文件，无需打包新的版本", "好的");
                return;
            }
            build();
            string dir = null;
            string dirPath = null;
            switch (platform)
            {
                case PlatformType.Android:
                    dir = savePath + "/Android/"+version;

                    dirPath = dir + "/temp";
                    if (Directory.Exists(dirPath) == false)
                    {
                        Directory.CreateDirectory(dirPath); //创建路径
                    }
                    //打AB包
                    BuildPipeline.BuildAssetBundles(dirPath, BuildAssetBundleOptions.None, BuildTarget.Android);
                    break;
                case PlatformType.iOS:
                    dir = savePath + "/iOS/" + version;

                    dirPath = dir + "/temp";
                    if (Directory.Exists(dirPath) == false)
                    {
                        Directory.CreateDirectory(dirPath); //创建路径
                    }
                    //打AB包
                    BuildPipeline.BuildAssetBundles(dirPath, BuildAssetBundleOptions.None, BuildTarget.iOS);
                    break;
            }
            resetAbInfo(buildPath);
            string zipFile = dir + "/" + version + ".zip";
            try
            {
                if (File.Exists(zipFile))
                {
                    File.Delete(zipFile);
                }
                EditorZipTool.Zip(dirPath, dir, version + ".zip");
                Directory.Delete(dirPath, true);
                writeFileList();
                writeVersion(dir);
                writeLocalVersion();
            }
            catch (Exception e)
            {
                EditorUtility.DisplayDialog("错误",
                    string.Format("打包失败，msg="+e.Message),
                    "知道了");
                return;
            }
            EditorUtility.DisplayDialog("提示",
                    string.Format("打包完成"),
                    "知道了");
            AssetDatabase.Refresh();
        }
    }
    
    List<string> needBuildFiles = new List<string>();
    Dictionary<string, string> allFiles = new Dictionary<string, string>();
    bool cancelPack = false;
    void loadFileList()
    {
        needBuildFiles.Clear();
        allFiles.Clear();
        getAllFiles(buildPath);

        if (!File.Exists(fileListPath))
        {
            if (version > 1)
            {
                if(EditorUtility.DisplayDialog("警告",
                    string.Format("没有找到版本号为{0}的文件列表", version - 1),
                    "继续打包", "取消"))
                {
                    cancelPack = false;
                }
                else
                {
                    cancelPack = true;
                }
            }
            return;
        }
        string str = File.ReadAllText(fileListPath);

        string md5;
        try
        {
            FileList list = JsonUtility.FromJson<FileList>(str);
            if (list != null && list.list != null)
            {
                List<FileItemInfo> md5Fs = list.list;
                FileItemInfo fii;
                for (int i = 0; i < md5Fs.Count; i++)
                {
                    fii = md5Fs[i];
                    if (needBuildFiles.Contains(fii.path))
                    {
                        md5 = getMd5(fii.path);
                        if (md5 == fii.md5)//相同MD5，则无需打包
                        {
                            needBuildFiles.Remove(fii.path);
                        }
                        allFiles[fii.path] = md5;
                    }
                }
            }
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
    }
    void writeLocalVersion()
    {
        if (updateLocalVersion)
        {
            if ((!string.IsNullOrEmpty(localVerPath)))
            {
                if (!File.Exists(localVerPath))
                {
                    File.Create(localVerPath).Dispose();
                }
                VersionInfo vi = new VersionInfo() { ver = version };
                File.WriteAllText(localVerPath, JsonUtility.ToJson(vi));
            }
            else
            {
                throw new FileNotFoundException("localVerPath == null");
            }
        }
    }
    void writeVersion(string path)
    {
        path = path + "/ver.txt";
        if (!File.Exists(path))
        {
            File.Create(path).Dispose();
        }
        VersionInfo vi = new VersionInfo() { ver = version };
        File.WriteAllText(path, JsonUtility.ToJson(vi));
    }
    void writeFileList()
    {
        Dictionary<string, string> newFs = new Dictionary<string, string>();
        foreach (var item in allFiles)
        {
            if (item.Value == null)
            {
                newFs[item.Key] = getMd5(item.Key);
            }
        }
        foreach (var item in newFs)
        {
            allFiles[item.Key] = item.Value;
        }
        FileList fl = new FileList() { list = new List<FileItemInfo>() };
        foreach (var item in allFiles)
        {
            fl.list.Add(new FileItemInfo() { path = item.Key, md5 = item.Value });
        }
        string str = JsonUtility.ToJson(fl);
        //Debug.LogError(str);
        if (!File.Exists(newFileListPath))
        {
            File.Create(newFileListPath).Dispose();
        }
        File.WriteAllText(newFileListPath, str);
    }
    void build()
    {
        //if (!Directory.Exists(path))
        //{
        //    Debug.LogError(string.Format("路径{0}不存在", path));
        //    return;
        //}
        //string[] paths = Directory.GetDirectories(path);
        //string[] fs = Directory.GetFiles(path);
        string _assetPath;
        string _resPath;
        for (int i = 0; i < needBuildFiles.Count; i++)
        {
            if (!needBuildFiles[i].EndsWith(".meta"))
            {
                _assetPath = "Assets" + needBuildFiles[i].Substring(Application.dataPath.Length);
                _resPath = needBuildFiles[i].Replace("\\", "/").Substring((buildPath + "/").Length);
                AssetImporter ai = AssetImporter.GetAtPath(_assetPath);
                ai.assetBundleName = GetFilePathNoSuffix(_resPath);
                ai.assetBundleVariant = abSuffix;
            }
        }
        //for (int i = 0; i < paths.Length; i++)
        //{
        //    build(paths[i]);
        //}
    }
    void getAllFiles(string path)
    {
        if (!Directory.Exists(path))
        {
            Debug.LogError(string.Format("路径{0}不存在", path));
            return;
        }
        string[] paths = Directory.GetDirectories(path);
        string[] fs = Directory.GetFiles(path);
        string temp;
        for (int i = 0; i < fs.Length; i++)
        {
            if (!fs[i].EndsWith(".meta"))
            {
                temp = fs[i].Replace("\\", "/");
                needBuildFiles.Add(temp);
                allFiles.Add(temp, null);
            }
        }
        for (int i = 0; i < paths.Length; i++)
        {
            getAllFiles(paths[i]);
        }
    }
    void resetAbInfo(string path)
    {
        if (!Directory.Exists(path))
        {
            Debug.LogError(string.Format("路径{0}不存在", path));
            return;
        }
        string[] paths = Directory.GetDirectories(path);
        string[] fs = Directory.GetFiles(path);
        string _assetPath;
        string _resPath;
        for (int i = 0; i < fs.Length; i++)
        {
            if (!fs[i].EndsWith(".meta"))
            {
                _assetPath = "Assets" + fs[i].Substring(Application.dataPath.Length);
                _resPath = fs[i].Replace("\\", "/").Substring((buildPath + "/").Length);
                AssetImporter ai = AssetImporter.GetAtPath(_assetPath);
                ai.assetBundleName = null;
                //ai.assetBundleVariant = "";
            }
        }
        for (int i = 0; i < paths.Length; i++)
        {
            resetAbInfo(paths[i]);
        }
    }
    string GetFilePathNoSuffix(string path)
    {
        //return System.IO.Path.ChangeExtension(path,"");
        return path.Replace(System.IO.Path.GetExtension(path), "");
    }

    string getMd5(string filePath)
    {
        try
        {
            FileStream fs = new FileStream(filePath, FileMode.Open);
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] bs = md5.ComputeHash(fs);
            fs.Close();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bs.Length; i++)
            {
                sb.Append(bs[i]);
            }
            return sb.ToString();
        }
        catch (Exception e)
        {
            throw new Exception(string.Format("path = {0},get md5 fail,error:", filePath) + e.Message);
        }
    }
}
