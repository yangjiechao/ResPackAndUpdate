﻿//-------------------------------------------------
// Copyright © 2019  yangjiechao
//-------------------------------------------------
[System.Serializable]
public class VersionInfo 
{
    public int ver;
}