﻿//-------------------------------------------------
// Copyright © 2019  yangjiechao
//-------------------------------------------------
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using System.IO;
using System;
using ICSharpCode.SharpZipLib.Zip;
/// <summary>
/// 版本管理
/// </summary>
public class VersionManager : MonoBehaviour
{
    static VersionManager _inst;
    public static VersionManager inst
    {
        get
        {
            if (_inst == null)
            {
                GameObject go = new GameObject("VersionManager");
                DontDestroyOnLoad(go);
                _inst = go.AddComponent<VersionManager>();
            }
            return _inst;
        }
    }
    //public System.Action<float> OnDownload;
    public System.Action<Phase> OnVersionPhaseChange;
    public System.Action<Phase, string> OnVersionError;
    public enum Phase
    {
        None,
        Check,
        DownLoad,
        Copy,
        UnZip,
        Complected,
    }
    /// <summary>
    /// 当前阶段
    /// </summary>
    public Phase phase;
    /// <summary>
    /// 本地版本号
    /// </summary>
    public int curVersion;
    /// <summary>
    /// 服务器版本号
    /// </summary>
    public int serVersion = -1;
    string serPath, tempPath, resPath, unZipPath, verTxtPath, verName;
    /// <summary>
    /// 初始化
    /// </summary>
    /// <param name="_serPath"></param>
    public void Init(string _serPath)
    {
        tempPath = Application.persistentDataPath + "/temp";
        unZipPath = tempPath + "/temp";
        resPath = Application.persistentDataPath + "/Resources";
        verName = "ver";
        verTxtPath = resPath + string.Format("/{0}.txt", verName);
        changePhase(Phase.Check);
        if (string.IsNullOrEmpty(_serPath))
        {
            Debug.LogError("_serPath == null");
            OnVersionError?.Invoke(phase, "_serPath == null");
            return;
        }
        serPath = _serPath;
        StartCoroutine(getServerVersion());
    }
    /// <summary>
    /// 获取下载进度
    /// </summary>
    /// <returns></returns>
    public float GetDownLoadProgress()
    {
        if (downDownRequest == null)
        {
            return 0;
        }
        return downDownRequest.downloadProgress;
    }
    //对比版本
    void CheckVersion(bool loadLocalFile = true)
    {
        if (loadLocalFile)
        {
            getCurVersionInfo((str) => {
                if (!string.IsNullOrEmpty(str))
                {
                    VersionInfo vi = JsonUtility.FromJson<VersionInfo>(str);
                    curVersion = getVersion(vi);
                }
                compareVersion();
            });
        }
        else
        {
            compareVersion();
        }
    }
    void compareVersion()
    {
        if (curVersion < serVersion)
        {
            curVersion++;
            Download();
        }
        else
        {
            if (Directory.Exists(tempPath))
            {
                Directory.Delete(tempPath, true);
            }
            changePhase(Phase.Complected);
        }
    }
    //下载
    void Download()
    {
        changePhase(Phase.DownLoad);
        if (Directory.Exists(unZipPath))
        {
            Directory.Delete(unZipPath, true);
        }
        StartCoroutine(getServerSrc());
    }
    UnityWebRequest downDownRequest;
    StreamWriter sw;
    IEnumerator getServerSrc()
    {
        string url = serPath + string.Format("/{0}.zip", curVersion);
        downDownRequest = UnityWebRequest.Get(url);
        yield return downDownRequest.SendWebRequest();
        if (!string.IsNullOrEmpty(downDownRequest.error))
        {
            OnVersionError?.Invoke(phase, downDownRequest.error + ",url=" + serPath + string.Format("/{0}.zip", curVersion));
        }
        else if (downDownRequest.isDone)
        {
            byte[] bs = downDownRequest.downloadHandler.data;
            if (bs == null)
            {
                OnVersionError?.Invoke(phase, "webRequest.downloadHandler.data == null");
            }
            else
            {
                changePhase(Phase.Copy);
                if (!Directory.Exists(tempPath))
                {
                    Directory.CreateDirectory(tempPath);
                }
                try
                {
                    //File.WriteAllBytes(tempPath + "/temp.zip", bs);
                    sw = new StreamWriter(tempPath + "/temp.zip");
                    sw.BaseStream.BeginWrite(bs, 0, bs.Length, onCopy, null);
                }
                catch (Exception e)
                {
                    OnVersionError?.Invoke(phase, e.Message);
                }
            }
        }
        else
        {
            OnVersionError?.Invoke(phase, "webRequest.isDone == false");
        }
    }

    bool isCopyed = false;
    bool isUnziped = false;
    private void Update()
    {
        if (isCopyed)
        {
            isCopyed = false;
            unZipPhase();
        }
        if (isUnziped)
        {
            isUnziped = false;
            writeVersion();
            CheckVersion(false);//再次对比版本
        }
    }
    private void onCopy(IAsyncResult ar)
    {
        sw.Flush();
        sw.Close();
        sw = null;
        isCopyed = true;
    }
    void unZipPhase()
    {
        changePhase(Phase.UnZip);
        try
        {
            UnZip(tempPath, unZipPath, "temp.zip");
            //解压完成后，复制到资源文件夹
            //Directory.Move(unZipPath, resPath);
            CopyFiles(unZipPath, resPath);
            isUnziped = true;
        }
        catch (Exception e)
        {
            OnVersionError?.Invoke(phase, e.Message);
        }
    }
    IEnumerator getServerVersion()
    {
        UnityWebRequest webRequest = UnityWebRequest.Get(serPath + "/ver.txt");
        yield return webRequest.SendWebRequest();
        if (!string.IsNullOrEmpty(webRequest.error))
        {
            OnVersionError?.Invoke(phase, webRequest.error);
        }
        else if (webRequest.isDone)
        {
            string text = webRequest.downloadHandler.text;
            if (string.IsNullOrEmpty(text))
            {
                OnVersionError?.Invoke(phase, "webRequest.downloadHandler.text == null");
            }
            else
            {
                VersionInfo vi = JsonUtility.FromJson<VersionInfo>(text);
                serVersion = getVersion(vi);
                CheckVersion();
            }
        }
        else
        {
            OnVersionError?.Invoke(phase, "webRequest.isDone == false");
        }
    }
    //写入版本
    void writeVersion()
    {
        VersionInfo vi = new VersionInfo() { ver = curVersion };
        File.WriteAllText(resPath + "/ver.txt", JsonUtility.ToJson(vi));
    }
    void changePhase(Phase _phase)
    {
        phase = _phase;
        OnVersionPhaseChange(_phase);
    }
    int getVersion(VersionInfo vi)
    {
        int v = 0;
        if (vi != null)
        {
            v = vi.ver;
        }
        return v;
    }
    private void CopyFiles(string varFromDirectory, string varToDirectory)
    {
        if (!Directory.Exists(varToDirectory))
        {
            Directory.CreateDirectory(varToDirectory);
        }
        if (!Directory.Exists(varFromDirectory)) return;
        string[] directories = Directory.GetDirectories(varFromDirectory);
        if (directories.Length > 0)
        {
            foreach (string d in directories)
            {
                CopyFiles(d, varToDirectory + d.Substring(d.LastIndexOf("\\")));
            }
        }
        string[] files = Directory.GetFiles(varFromDirectory);
        if (files.Length > 0)
        {
            foreach (string s in files)
            {
                File.Copy(s, varToDirectory + s.Substring(s.LastIndexOf("\\")), true);
            }
        }
    }
    void getCurVersionInfo(System.Action<string> callBack)
    {
        string str = null;
        try
        {
            if (File.Exists(verTxtPath))
            {
                str = File.ReadAllText(verTxtPath);
            }
            else
            {
                TextAsset ta = Resources.Load<TextAsset>(verName);
                if (ta != null)
                {
                    str = ta.text;
                }
            }
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        callBack?.Invoke(str);
    }
    const string suffix = ".zip";
    /// <summary>
    /// 解压
    /// </summary>
    /// <param name="srcPath"></param>
    /// <param name="destPath"></param>
    /// <param name="zipName"></param>
    public static void UnZip(string srcPath, string destPath, string zipName)
    {
        if (string.IsNullOrEmpty(srcPath) || string.IsNullOrEmpty(destPath) || string.IsNullOrEmpty(zipName))
        {
            Debug.LogError(string.Format("解压出错,srcPath={0},destPath={1},zipName={2}", srcPath, destPath, zipName));
            return;
        }
        if (!zipName.EndsWith(suffix))
        {
            zipName += suffix;
        }
        string zipPath = srcPath + "/" + zipName;
        if (!System.IO.File.Exists(zipPath))
        {
            Debug.LogError("找不到解压文件" + zipPath);
            return;
        }
        if (!System.IO.Directory.Exists(destPath))
        {
            System.IO.Directory.CreateDirectory(destPath);
        }
        if (!zipName.EndsWith(suffix))
        {
            zipName += suffix;
        }
        try
        {
            //ZipFile.ExtractToDirectory(zipPath, destPath,System.Text.Encoding.UTF8);
            __unzip(zipPath,destPath);
        }
        catch (System.Exception e)
        {
            Debug.LogError(e);
        }
    }
    static void __unzip(string fileToUnZip, string zipedFolder)
    {
        FileStream fs = null;
        ZipInputStream zipStream = null;
        ZipEntry ent = null;
        string fileName;
        if (!File.Exists(fileToUnZip))
            return;
        if (!Directory.Exists(zipedFolder))
            Directory.CreateDirectory(zipedFolder);
        try
        {
            zipStream = new ZipInputStream(File.OpenRead(fileToUnZip));
            while ((ent = zipStream.GetNextEntry()) != null)
            {
                if (!string.IsNullOrEmpty(ent.Name))
                {
                    fileName = Path.Combine(zipedFolder, ent.Name);
                    fileName = fileName.Replace('/', '\\');  
                    if (fileName.EndsWith("\\"))
                    {
                        Directory.CreateDirectory(fileName);
                        continue;
                    }
                    fs = File.Create(fileName);
                    int size = 2048;
                    byte[] data = new byte[size];
                    while (true)
                    {
                        size = zipStream.Read(data, 0, data.Length);
                        if (size > 0)
                            fs.Write(data, 0, size);
                        else
                            break;
                    }
                }
            }
        }
        catch(Exception e)
        {
            Debug.LogError(e);
        }
        finally
        {
            if (fs != null)
            {
                fs.Close();
                fs.Dispose();
            }
            if (zipStream != null)
            {
                zipStream.Close();
                zipStream.Dispose();
            }
            if (ent != null)
            {
                ent = null;
            }
            GC.Collect();
            //GC.Collect(1);
        }
    }
}
